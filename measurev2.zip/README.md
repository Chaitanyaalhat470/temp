# Grating Measurement — AOI Tool (Django)

Automated Optical Inspection for industrial gratings. Teach the system once on
a **master** grating (click its features), then **auto-measure** every unit of
that type. Built for a fixed top-down camera with controlled lighting.

## What's here

| Path | Role |
|---|---|
| `measure_project/` | Django project (settings, urls, wsgi/asgi) |
| `inspection/` | Main app: models, views, templates, vision pipeline |
| `inspection/vision/` | CV core — `edges.py`, `measure.py` (Livewire + circle), `registration.py`, `pipeline.py`, `dexined.py` |
| `static/inspection/` | Canvas JS + CSS |
| `grating_edges.py`, `calibrate.py`, `measure_proto.py` | Earlier standalone prototypes (kept for reference) |

## Concept

Works for **arbitrary grating shapes** (not just rectangles).

0. **Calibrate the rig once** — set one global **mm-per-pixel** (Calibration
   page) from a checkerboard (`calibrate.py`) or any known length. It's a
   property of the fixed top-down camera, independent of part shape.
1. **Create a grating type** — upload a master image. The type inherits the
   global mm/px.
2. **Teach** — on a canvas, define features two ways:
   - **Auto-detect (recommended):** click *Detect lines + circles* → the system
     finds all straight lines + circles above a threshold → **hover to highlight,
     click to select** one (like picking a series on a graph).
   - **Manual:** **Length** = click A then B (snaps along the contour, Livewire);
     **Notch radius** = click 3 points → a circle is fit.
   Features are stored in **master-image coordinates**.
3. **Inspect** — upload a new unit. The system aligns it to the master by
   **silhouette registration** (a small translation+rotation that works for any
   outline), replays each feature, and **re-measures that unit's own edges** →
   results in mm. (Raw values; tolerance/pass-fail is not enabled yet.)

## Setup (on the target machine)

```bash
# 1. (recommended) virtual env
python -m venv .venv
.venv\Scripts\activate            # Windows
# source .venv/bin/activate       # Linux/Mac

# 2. dependencies
pip install -r requirements.txt

# 3. database
python manage.py makemigrations inspection
python manage.py migrate

# 4. (optional) admin user to browse data at /admin/
python manage.py createsuperuser

# 5. run
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Edge detector

Default is **Canny** (no extra dependencies, ideal for clean rig images).
To use **DexiNed** instead (more robust, needs PyTorch + weights):

```bash
# Windows PowerShell
$env:EDGE_METHOD = "dexined"
# place 10_model.pth in the project root, or set DEXINED_WEIGHTS
pip install torch torchvision
python manage.py runserver
```

Optional background removal (usually unnecessary on a controlled rig):
`$env:USE_REMBG = "1"`.

## Notes / limitations

- **Calibration** is one global mm/px for the fixed top-down camera (uniform
  across the frame, any shape). Re-run it on the Calibration page if the camera
  moves or the FOV changes.
- **Registration** aligns the subject to the master by **silhouette** (similarity
  transform: translation + small rotation). Works for any outline; assumes the
  part is placed at roughly the same orientation. Relies on detecting the part
  silhouette against the background — controlled lighting + plain background
  makes this reliable; a cluttered background can break it (Inspect flags this).
- **ROI tuning:** auto-measure re-snaps near the projected feature location. On a
  regular lattice, if a feature sits very close to identical neighbours, the snap
  could grab an adjacent edge — tune by teaching anchors precisely on the bar.
- API endpoints are **CSRF-exempt** for this internal single-machine tool. Add
  CSRF + auth before any networked deployment, and set `DEBUG=0`, a real
  `DJANGO_SECRET_KEY`, and proper `ALLOWED_HOSTS`.
```
