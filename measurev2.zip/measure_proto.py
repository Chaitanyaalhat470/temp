"""
measure_proto.py  --  Phase 2 core-algorithm PROTOTYPE
=======================================================

Goal: de-risk the two hard interactive measurements BEFORE building the web UI.
The functions here (cost map, Livewire path, circle fit) are written to be
portable -- they will become the FastAPI backend later. The cv2 window is only
a throwaway test harness so we can click and see if the algorithms work.

Two tools, exactly as specified:

  * LENGTH (key 'l'):  click point A, then point B.  The system snaps a
    continuous curve ALONG the detected contour between A and B (Intelligent
    Scissors / Livewire = Dijkstra shortest-path on an edge-cost map) and
    reports its length.  After A is set, the wire previews live to the cursor.

  * RADIUS (key 'c'): click 3 points on a notch arc.  Each click snaps to the
    nearest edge pixel; a circle is least-squares fit (and refined against
    nearby edge pixels) and the radius is reported.

----------------------------------------------------------------------------
USAGE
----------------------------------------------------------------------------
  pip install opencv-contrib-python numpy

  # Use the precise DexiNed edge map saved by grating_edges.py --save-edgemap:
  python measure_proto.py --image grating.jpg --edgemap grating_out_edgemap.npy

  # Or let it compute Canny edges on the fly (great for clean rig images):
  python measure_proto.py --image grating.jpg

  # If you know the scale, pass it so lengths print in mm (else in pixels):
  python measure_proto.py --image grating.jpg --mm-per-px 0.135

KEYS:  l = length tool   c = circle tool   r = reset   q = quit
"""

import time
import heapq
import argparse

import cv2
import numpy as np


# Cap the resolution we run Dijkstra on, so the live wire stays responsive.
# Measurements are converted back to original-image pixels before scaling.
PROC_MAX = 900


# ===========================================================================
#  Edge cost map
# ===========================================================================
def load_edge_map(image_path, edgemap_path):
    """Return (display_bgr, edge_float[0..1]) at original resolution."""
    bgr = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(image_path)

    if edgemap_path:
        edge = np.load(edgemap_path).astype(np.float32)
        if edge.shape[:2] != bgr.shape[:2]:
            edge = cv2.resize(edge, (bgr.shape[1], bgr.shape[0]))
    else:
        # On-the-fly Canny -> blurred into a soft strength map.
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        canny = cv2.Canny(gray, 50, 150).astype(np.float32) / 255.0
        edge = cv2.GaussianBlur(canny, (0, 0), 1.0)

    edge = (edge - edge.min()) / (edge.max() - edge.min() + 1e-8)
    return bgr, edge


def build_cost(edge):
    """Edge-following cost: strong edges => low cost (the path is drawn to them)."""
    # Emphasise strong edges, then invert. gamma<1 sharpens the contrast.
    strength = np.power(edge, 0.5)
    cost = 1.0 - strength
    return (cost + 1e-3).astype(np.float32)      # keep strictly positive


# ===========================================================================
#  Livewire  (Dijkstra from a seed; live backtrack to any cursor point)
# ===========================================================================
class Livewire:
    """Dijkstra from one seed over the whole cost grid; O(1) path to any point."""

    def __init__(self, cost):
        self.cost = cost
        self.h, self.w = cost.shape
        self.came_from = None
        self.seed = None

    def set_seed(self, seed):
        """Run Dijkstra once from seed=(x,y); fills predecessor map for backtrack."""
        t0 = time.time()
        h, w = self.h, self.w
        cost = self.cost
        INF = np.float32(np.inf)
        dist = np.full((h, w), INF, dtype=np.float32)
        came = np.full((h, w), -1, dtype=np.int32)     # encoded prev index
        visited = np.zeros((h, w), dtype=bool)

        sx, sy = seed
        dist[sy, sx] = 0.0
        pq = [(0.0, sy * w + sx)]
        neigh = [(-1, -1, 1.41421356), (0, -1, 1.0), (1, -1, 1.41421356),
                 (-1, 0, 1.0),                       (1, 0, 1.0),
                 (-1, 1, 1.41421356), (0, 1, 1.0), (1, 1, 1.41421356)]

        while pq:
            d, idx = heapq.heappop(pq)
            y, x = divmod(idx, w)
            if visited[y, x]:
                continue
            visited[y, x] = True
            for dx, dy, step in neigh:
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and not visited[ny, nx]:
                    nd = d + step * cost[ny, nx]
                    if nd < dist[ny, nx]:
                        dist[ny, nx] = nd
                        came[ny, nx] = idx
                        heapq.heappush(pq, (nd, ny * w + nx))

        self.came_from = came
        self.seed = seed
        print(f"[livewire] seed Dijkstra: {time.time() - t0:.2f}s "
              f"({h*w} px)")

    def path_to(self, pt):
        """Backtrack the snapped path from the seed to pt=(x,y). List of (x,y)."""
        if self.came_from is None:
            return []
        w = self.w
        x, y = pt
        path = [(x, y)]
        idx = self.came_from[y, x]
        guard = 0
        while idx != -1 and guard < self.h * self.w:
            py, px = divmod(int(idx), w)
            path.append((px, py))
            idx = self.came_from[py, px]
            guard += 1
        path.reverse()
        return path


def polyline_length(path):
    """Euclidean length of a list of (x,y) points, in pixels."""
    if len(path) < 2:
        return 0.0
    p = np.asarray(path, dtype=np.float64)
    return float(np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1)))


# ===========================================================================
#  Snapping + circle fit
# ===========================================================================
def snap_to_edge(edge, pt, win=12, thresh=0.3):
    """Move a click to the strongest edge pixel within +/-win. Sub-pixel-ish."""
    x, y = pt
    h, w = edge.shape
    x0, x1 = max(0, x - win), min(w, x + win + 1)
    y0, y1 = max(0, y - win), min(h, y + win + 1)
    patch = edge[y0:y1, x0:x1]
    if patch.max() < thresh:
        return (x, y)                       # nothing strong nearby; keep click
    ay, ax = np.unravel_index(np.argmax(patch), patch.shape)
    return (x0 + ax, y0 + ay)


def fit_circle_ls(points):
    """Algebraic (Kasa) least-squares circle fit. Returns (cx, cy, r)."""
    p = np.asarray(points, dtype=np.float64)
    x, y = p[:, 0], p[:, 1]
    A = np.column_stack([x, y, np.ones(len(p))])
    b = x ** 2 + y ** 2
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    cx, cy = sol[0] / 2.0, sol[1] / 2.0
    r = np.sqrt(sol[2] + cx ** 2 + cy ** 2)
    return cx, cy, r


def refine_circle(edge, c, r, band=6, thresh=0.3):
    """Collect edge pixels in a band around the initial circle, then refit."""
    cx, cy, r0 = c[0], c[1], r
    ys, xs = np.nonzero(edge >= thresh)
    if len(xs) == 0:
        return c[0], c[1], r
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
    keep = np.abs(d - r0) <= band
    if keep.sum() < 5:
        return c[0], c[1], r
    return fit_circle_ls(np.column_stack([xs[keep], ys[keep]]))


# ===========================================================================
#  Interactive test harness (throwaway cv2 window)
# ===========================================================================
class App:
    def __init__(self, bgr, edge, mm_per_px, scale):
        self.bgr = bgr                       # proc-resolution display image
        self.edge = edge                     # proc-resolution edge map
        self.mm_per_px = mm_per_px
        self.scale = scale                   # proc_px = orig_px * scale
        self.cost = build_cost(edge)
        self.lw = Livewire(self.cost)
        self.mode = "length"                 # or "circle"
        self.seed = None
        self.cursor = None
        self.circle_pts = []
        self.result = None
        self.win = "measure_proto  [l]ength  [c]ircle  [r]eset  [q]uit"
        cv2.namedWindow(self.win)
        cv2.setMouseCallback(self.win, self.on_mouse)

    def to_mm(self, px_len_proc):
        """proc pixels -> original pixels -> mm (or stays px if mm_per_px is None)."""
        orig_px = px_len_proc / self.scale
        if self.mm_per_px:
            return orig_px * self.mm_per_px, "mm"
        return orig_px, "px"

    def on_mouse(self, event, x, y, flags, param):
        self.cursor = (x, y)
        if event != cv2.EVENT_LBUTTONDOWN:
            return

        if self.mode == "length":
            snapped = snap_to_edge(self.edge, (x, y))
            if self.seed is None:
                self.seed = snapped
                self.lw.set_seed(self.seed)
            else:
                path = self.lw.path_to(snapped)
                length_proc = polyline_length(path)
                val, unit = self.to_mm(length_proc)
                self.result = (f"length = {val:.2f} {unit}", path, None)
                self.seed = None             # ready for next measurement
        else:  # circle
            self.circle_pts.append(snap_to_edge(self.edge, (x, y)))
            if len(self.circle_pts) == 3:
                cx, cy, r = fit_circle_ls(self.circle_pts)
                cx, cy, r = refine_circle(self.edge, (cx, cy), r)
                val, unit = self.to_mm(r)
                self.result = (f"radius = {val:.2f} {unit}",
                               None, (int(cx), int(cy), int(r)))
                self.circle_pts = []

    def render(self):
        view = self.bgr.copy()
        # paint detected edges faintly so the user sees what they snap to
        view[self.edge >= 0.4] = (0, 255, 255)

        # live wire preview
        if self.mode == "length" and self.seed is not None and self.cursor:
            path = self.lw.path_to(self.cursor)
            for i in range(1, len(path)):
                cv2.line(view, path[i - 1], path[i], (0, 0, 255), 2)
            cv2.circle(view, self.seed, 4, (0, 255, 0), -1)

        for p in self.circle_pts:
            cv2.circle(view, p, 4, (255, 0, 0), -1)

        if self.result:
            text, path, circ = self.result
            if path:
                for i in range(1, len(path)):
                    cv2.line(view, path[i - 1], path[i], (0, 0, 255), 2)
            if circ:
                cv2.circle(view, (circ[0], circ[1]), circ[2], (0, 0, 255), 2)
                cv2.circle(view, (circ[0], circ[1]), 3, (0, 0, 255), -1)
            cv2.putText(view, text, (10, 28), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (0, 0, 0), 4, cv2.LINE_AA)
            cv2.putText(view, text, (10, 28), cv2.FONT_HERSHEY_SIMPLEX,
                        0.8, (255, 255, 255), 1, cv2.LINE_AA)

        cv2.putText(view, f"mode: {self.mode}", (10, view.shape[0] - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
        return view

    def run(self):
        while True:
            cv2.imshow(self.win, self.render())
            k = cv2.waitKey(20) & 0xFF
            if k == ord('q'):
                break
            elif k == ord('l'):
                self.mode, self.seed, self.circle_pts, self.result = \
                    "length", None, [], None
            elif k == ord('c'):
                self.mode, self.seed, self.circle_pts, self.result = \
                    "circle", None, [], None
            elif k == ord('r'):
                self.seed, self.circle_pts, self.result = None, [], None
        cv2.destroyAllWindows()


def main():
    ap = argparse.ArgumentParser(description="Prototype: Livewire length + circle fit.")
    ap.add_argument("--image", required=True)
    ap.add_argument("--edgemap", default=None,
                    help="precise edge map .npy from grating_edges.py --save-edgemap")
    ap.add_argument("--mm-per-px", type=float, default=None,
                    help="scale from calibration; omit to report lengths in pixels")
    args = ap.parse_args()

    bgr, edge = load_edge_map(args.image, args.edgemap)

    # Downscale to PROC_MAX for a responsive live wire; remember the factor.
    h, w = edge.shape
    scale = min(1.0, PROC_MAX / max(h, w))
    if scale < 1.0:
        bgr = cv2.resize(bgr, (int(w * scale), int(h * scale)))
        edge = cv2.resize(edge, (int(w * scale), int(h * scale)))
        print(f"[i] processing at {edge.shape[1]}x{edge.shape[0]} (scale {scale:.3f})")

    App(bgr, edge, args.mm_per_px, scale).run()


if __name__ == "__main__":
    main()
