from django.contrib import admin

from .models import (GratingType, Feature, InspectionRun, Measurement,
                     RigCalibration)


@admin.register(RigCalibration)
class RigCalibrationAdmin(admin.ModelAdmin):
    list_display = ("mm_per_px", "source", "updated_at")


class FeatureInline(admin.TabularInline):
    model = Feature
    extra = 0


@admin.register(GratingType)
class GratingTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "mm_per_px", "is_calibrated", "is_taught", "created_at")
    inlines = [FeatureInline]


@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    list_display = ("name", "grating_type", "kind", "created_at")
    list_filter = ("kind", "grating_type")


class MeasurementInline(admin.TabularInline):
    model = Measurement
    extra = 0


@admin.register(InspectionRun)
class InspectionRunAdmin(admin.ModelAdmin):
    list_display = ("pk", "grating_type", "created_at")
    inlines = [MeasurementInline]


@admin.register(Measurement)
class MeasurementAdmin(admin.ModelAdmin):
    list_display = ("feature", "value_mm", "value_px", "unit", "ok", "run")
