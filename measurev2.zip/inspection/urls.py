from django.urls import path

from . import views

urlpatterns = [
    # Pages
    path("", views.index, name="index"),
    path("calibration/", views.calibration, name="calibration"),
    path("types/new/", views.create_type, name="create_type"),
    path("types/<int:type_id>/teach/", views.teach, name="teach"),
    path("types/<int:type_id>/inspect/", views.inspect, name="inspect"),

    # API
    path("api/prepare/", views.api_prepare, name="api_prepare"),
    path("api/primitives/", views.api_detect_primitives, name="api_detect_primitives"),
    path("api/measure/length/", views.api_measure_length, name="api_measure_length"),
    path("api/measure/circle/", views.api_measure_circle, name="api_measure_circle"),
    path("api/types/<int:type_id>/features/", views.api_save_features,
         name="api_save_features"),
    path("api/types/<int:type_id>/inspect/", views.api_inspect, name="api_inspect"),
]
