"""
Data model for the AOI grating-measurement tool.

Works for ARBITRARY grating outlines (no rectangle assumption):
  * Calibration (mm/px) is a RIG CONSTANT (fixed top-down camera), set once
    from a checkerboard/known scale -- independent of part shape.
  * Features are stored in MASTER-IMAGE pixel coordinates. At inspection time
    the subject is aligned to the master by SILHOUETTE registration (similarity
    transform), so features transfer regardless of outline shape.
"""
from django.db import models


class RigCalibration(models.Model):
    """Single global scale for the fixed-FOV rig (mm per pixel)."""
    mm_per_px = models.FloatField()
    source = models.CharField(
        max_length=120, blank=True,
        help_text="How it was obtained, e.g. 'checkerboard 25mm, calibrate.py'.")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Rig calibration"
        verbose_name_plural = "Rig calibration"

    def __str__(self):
        return f"{self.mm_per_px:.6f} mm/px"

    @classmethod
    def current(cls):
        return cls.objects.order_by("-updated_at").first()


class GratingType(models.Model):
    name = models.CharField(max_length=120, unique=True)
    description = models.TextField(blank=True)

    master_image = models.ImageField(upload_to="masters/")

    # mm/px snapshot used for this type (copied from RigCalibration at creation,
    # editable). Uniform across the frame on a top-down rig.
    mm_per_px = models.FloatField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    @property
    def is_calibrated(self):
        return bool(self.mm_per_px)

    @property
    def is_taught(self):
        return self.features.exists()


class Feature(models.Model):
    LENGTH = "length"
    RADIUS = "radius"
    KIND_CHOICES = [(LENGTH, "Length (A->B along contour)"),
                    (RADIUS, "Notch radius (3-point circle)")]

    grating_type = models.ForeignKey(
        GratingType, related_name="features", on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    kind = models.CharField(max_length=16, choices=KIND_CHOICES)

    # Anchor points in MASTER-IMAGE pixel coordinates.
    #   length: {"a": [x, y], "b": [x, y]}
    #   radius: {"points": [[x,y],[x,y],[x,y]]}
    anchors_img = models.JSONField()

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]
        unique_together = [("grating_type", "name")]

    def __str__(self):
        return f"{self.grating_type.name} / {self.name} ({self.kind})"


class InspectionRun(models.Model):
    grating_type = models.ForeignKey(
        GratingType, related_name="runs", on_delete=models.CASCADE)
    subject_image = models.ImageField(upload_to="subjects/")
    # Detected outer silhouette polygon of this subject, [[x,y], ...].
    subject_outline = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Run #{self.pk} of {self.grating_type.name}"


class Measurement(models.Model):
    run = models.ForeignKey(
        InspectionRun, related_name="measurements", on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)

    value_px = models.FloatField()
    value_mm = models.FloatField(null=True, blank=True)
    unit = models.CharField(max_length=8, default="px")

    geometry = models.JSONField(null=True, blank=True)
    ok = models.BooleanField(default=True)
    note = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.feature.name} = {self.value_mm or self.value_px:.2f} {self.unit}"
