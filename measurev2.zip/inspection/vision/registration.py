"""
Registration for ARBITRARY grating shapes (no rectangle assumption).

The grating is flat under a fixed top-down camera and placed at roughly the
same orientation, so a subject differs from the master only by a small
translation + rotation (a similarity/Euclidean transform). We estimate that
transform by aligning the two SILHOUETTES -- which works for any outline.

  get_mask(bgr)                      -> filled silhouette mask + outer contour
  outline_polygon(bgr)               -> simplified outer polygon (for display)
  estimate_transform(m_mask, s_mask) -> 2x3 affine mapping MASTER px -> SUBJECT px
  warp_points(points, T)             -> apply the transform to points
"""
import numpy as np
import cv2


def get_mask(bgr):
    """Return (filled_silhouette_uint8, outer_contour) for the largest object."""
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    _, th = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    h, w = gray.shape
    best, best_area = None, 0
    for m in (th, cv2.bitwise_not(th)):
        m = cv2.morphologyEx(
            m, cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        a = cv2.contourArea(c)
        if a > best_area and a < 0.98 * w * h:
            best_area, best = a, c

    mask = np.zeros((h, w), np.uint8)
    if best is not None:
        cv2.drawContours(mask, [best], -1, 255, cv2.FILLED)
    return mask, best


def outline_polygon(bgr, eps_frac=0.005):
    """Simplified outer polygon of the part, for display. None if not found."""
    _mask, c = get_mask(bgr)
    if c is None:
        return None
    peri = cv2.arcLength(c, True)
    approx = cv2.approxPolyDP(c, eps_frac * peri, True)
    return approx.reshape(-1, 2).tolist()


def _centroid(mask):
    M = cv2.moments(mask, binaryImage=True)
    if M["m00"] == 0:
        return None
    return np.array([M["m10"] / M["m00"], M["m01"] / M["m00"]], dtype=np.float32)


def estimate_transform(master_mask, subject_mask):
    """
    2x3 affine T mapping MASTER pixel coords -> SUBJECT pixel coords.

    Coarse step: align centroids (translation). Refine: ECC (Euclidean =
    rotation + translation) on the blurred silhouettes. Falls back to the
    coarse translation if ECC fails to converge.
    """
    warp = np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32)
    cm, cs = _centroid(master_mask), _centroid(subject_mask)
    if cm is None or cs is None:
        return None
    warp[0, 2] = cs[0] - cm[0]
    warp[1, 2] = cs[1] - cm[1]

    # ECC: template=master, input=subject -> warp maps master coords -> subject.
    tmpl = cv2.GaussianBlur(master_mask.astype(np.float32) / 255.0, (0, 0), 3)
    inp = cv2.GaussianBlur(subject_mask.astype(np.float32) / 255.0, (0, 0), 3)
    try:
        criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-5)
        _, warp = cv2.findTransformECC(
            tmpl, inp, warp, cv2.MOTION_EUCLIDEAN, criteria, None, 5)
    except cv2.error:
        pass        # keep coarse translation-only estimate
    return warp


def warp_points(points, T):
    """Apply 2x3 affine T to a list of [x,y] points."""
    pts = np.asarray(points, dtype=np.float32).reshape(-1, 1, 2)
    out = cv2.transform(pts, T).reshape(-1, 2)
    return out.tolist()
