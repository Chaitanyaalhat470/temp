"""
Auto-detect geometric primitives (straight lines + circles) on the edge map so
the user can SELECT them on the canvas instead of tracing by hand.

  detect_lines(edge, ...)   -> merged, length-filtered straight segments
  detect_circles(bgr, ...)  -> Hough circles within a radius range

All coordinates are image pixels. Tunable thresholds let the UI control how
aggressive detection is.
"""
import numpy as np
import cv2


# --------------------------------------------------------------------------
# Lines
# --------------------------------------------------------------------------
def _binary_edges(edge, thresh=0.4):
    return (edge >= thresh).astype(np.uint8) * 255


def _seg_angle(s):
    x1, y1, x2, y2 = s
    return np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180.0


def _line_point_dist(seg, px, py):
    """Perpendicular distance from (px,py) to the infinite line through seg."""
    x1, y1, x2, y2 = seg
    dx, dy = x2 - x1, y2 - y1
    n = np.hypot(dx, dy)
    if n == 0:
        return np.hypot(px - x1, py - y1)
    return abs(dy * (px - x1) - dx * (py - y1)) / n


def _extreme(group):
    """Merge a group of near-collinear segments into one by extreme projection."""
    pts = []
    for x1, y1, x2, y2 in group:
        pts += [(x1, y1), (x2, y2)]
    pts = np.array(pts, dtype=np.float64)
    ang = np.radians(np.mean([_seg_angle(s) for s in group]))
    d = np.array([np.cos(ang), np.sin(ang)])
    t = pts @ d
    p0 = pts[int(np.argmin(t))]
    p1 = pts[int(np.argmax(t))]
    return (int(p0[0]), int(p0[1]), int(p1[0]), int(p1[1]))


def _merge_segments(segs, ang_tol=5.0, dist_tol=8.0):
    used = [False] * len(segs)
    merged = []
    for i, s in enumerate(segs):
        if used[i]:
            continue
        group = [s]
        used[i] = True
        ai = _seg_angle(s)
        for j in range(i + 1, len(segs)):
            if used[j]:
                continue
            aj = _seg_angle(segs[j])
            da = abs(ai - aj)
            da = min(da, 180 - da)
            if da > ang_tol:
                continue
            mx = (segs[j][0] + segs[j][2]) / 2.0
            my = (segs[j][1] + segs[j][3]) / 2.0
            if _line_point_dist(s, mx, my) <= dist_tol:
                group.append(segs[j])
                used[j] = True
        merged.append(_extreme(group))
    return merged


def detect_lines(edge, min_len_frac=0.05, max_gap=10, hough_thresh=50):
    """Return a list of merged, length-filtered straight segments."""
    h, w = edge.shape
    b = _binary_edges(edge)
    min_len = max(10, int(min_len_frac * max(h, w)))
    lines = cv2.HoughLinesP(b, 1, np.pi / 180, threshold=hough_thresh,
                            minLineLength=min_len, maxLineGap=max_gap)
    if lines is None:
        return []
    segs = [tuple(int(v) for v in l[0]) for l in lines]
    merged = _merge_segments(segs)
    out = []
    for i, (x1, y1, x2, y2) in enumerate(merged):
        length = float(np.hypot(x2 - x1, y2 - y1))
        if length < min_len:
            continue
        out.append({"id": f"L{i}", "x1": x1, "y1": y1, "x2": x2, "y2": y2,
                    "length_px": length})
    out.sort(key=lambda d: -d["length_px"])
    return out


# --------------------------------------------------------------------------
# Circles
# --------------------------------------------------------------------------
def detect_circles(bgr, dp=1.2, min_dist_frac=0.05, param1=120, param2=40,
                   min_r_frac=0.02, max_r_frac=0.6):
    """Return Hough circles within a radius range (fraction of the short side)."""
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 5)
    h, w = gray.shape
    short = min(h, w)
    circles = cv2.HoughCircles(
        gray, cv2.HOUGH_GRADIENT, dp=dp,
        minDist=max(10, int(min_dist_frac * short)),
        param1=param1, param2=param2,
        minRadius=int(min_r_frac * short), maxRadius=int(max_r_frac * short))
    if circles is None:
        return []
    circles = np.uint16(np.around(circles))[0]
    out = []
    for i, (cx, cy, r) in enumerate(circles):
        out.append({"id": f"C{i}", "cx": int(cx), "cy": int(cy), "r": int(r)})
    out.sort(key=lambda d: -d["r"])
    return out
