"""
Edge detection: produce a soft edge-strength map in [0, 1].

Two backends:
  * "canny"   -- pure OpenCV, no heavy deps. Default. Ideal for the clean,
                 controlled-lighting rig images.
  * "dexined" -- learned detector (needs torch + 10_model.pth). More robust on
                 messy images; slower.

Optionally runs rembg background removal first (controlled by settings).
"""
import numpy as np
import cv2
from django.conf import settings


def _canny_soft(bgr):
    """Canny edges, blurred into a soft strength map for cost building."""
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 5, 50, 50)        # denoise, keep edges
    # Auto thresholds from median (robust across lighting).
    v = float(np.median(gray))
    lo = int(max(0, 0.66 * v))
    hi = int(min(255, 1.33 * v))
    canny = cv2.Canny(gray, lo, hi).astype(np.float32) / 255.0
    return cv2.GaussianBlur(canny, (0, 0), 1.0)


def _maybe_rembg(bgr):
    if not settings.USE_REMBG:
        return bgr, None
    from rembg import remove, new_session
    session = new_session(settings.REMBG_MODEL)
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    rgba = np.asarray(remove(rgb, session=session))
    mask = (rgba[:, :, 3] > 10).astype(np.uint8) * 255
    return bgr, mask


def compute_edge_map(bgr):
    """Return float32 edge map in [0,1], same HxW as bgr."""
    bgr, mask = _maybe_rembg(bgr)

    method = settings.EDGE_METHOD.lower()
    if method == "dexined":
        from . import dexined
        edge = dexined.edge_map(bgr, settings.DEXINED_WEIGHTS)
    else:
        edge = _canny_soft(bgr)

    if mask is not None:
        edge = edge * (mask.astype(np.float32) / 255.0)

    edge = (edge - edge.min()) / (edge.max() - edge.min() + 1e-8)
    return edge.astype(np.float32)


def overlay_edges(bgr, edge, thresh=0.4, color=(0, 255, 255)):
    """Return a BGR copy with edge pixels painted (for display)."""
    out = bgr.copy()
    out[edge >= thresh] = color
    return out
