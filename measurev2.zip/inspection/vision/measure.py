"""
Measurement primitives (ported from measure_proto.py, made stateless):

  * build_cost(edge)            -- edge-following cost map.
  * livewire_path(cost, a, b)   -- Intelligent-Scissors path A->B (Dijkstra,
                                   bounded to the a/b bounding box for speed).
  * snap_to_edge(edge, pt)      -- pull a click to the strongest nearby edge.
  * fit_circle_ls(points)       -- algebraic least-squares circle.
  * refine_circle(edge, c, r)   -- refit using edge pixels in a band.
"""
import heapq
import numpy as np


def build_cost(edge):
    """Strong edges => low cost (the wire is attracted to them)."""
    strength = np.power(np.clip(edge, 0, 1), 0.5)
    return (1.0 - strength + 1e-3).astype(np.float32)


def snap_to_edge(edge, pt, win=12, thresh=0.3):
    """Move (x,y) to the strongest edge pixel within +/-win. Keeps click if none."""
    x, y = int(round(pt[0])), int(round(pt[1]))
    h, w = edge.shape
    x0, x1 = max(0, x - win), min(w, x + win + 1)
    y0, y1 = max(0, y - win), min(h, y + win + 1)
    patch = edge[y0:y1, x0:x1]
    if patch.size == 0 or patch.max() < thresh:
        return (x, y)
    ay, ax = np.unravel_index(int(np.argmax(patch)), patch.shape)
    return (x0 + int(ax), y0 + int(ay))


def livewire_path(cost, a, b, margin=40):
    """
    Shortest edge-hugging path from a=(x,y) to b=(x,y) over `cost`.

    Restricted to the bounding box of a and b (expanded by `margin`) so it runs
    fast even on large images. Returns a list of (x,y) in full-image coords.
    """
    h, w = cost.shape
    ax, ay = int(a[0]), int(a[1])
    bx, by = int(b[0]), int(b[1])

    x0 = max(0, min(ax, bx) - margin)
    y0 = max(0, min(ay, by) - margin)
    x1 = min(w, max(ax, bx) + margin + 1)
    y1 = min(h, max(ay, by) + margin + 1)
    sub = cost[y0:y1, x0:x1]
    sh, sw = sub.shape

    sa = (ax - x0, ay - y0)
    sb = (bx - x0, by - y0)

    INF = np.float32(np.inf)
    dist = np.full((sh, sw), INF, dtype=np.float32)
    came = np.full((sh, sw), -1, dtype=np.int32)
    visited = np.zeros((sh, sw), dtype=bool)

    dist[sa[1], sa[0]] = 0.0
    pq = [(0.0, sa[1] * sw + sa[0])]
    neigh = [(-1, -1, 1.41421356), (0, -1, 1.0), (1, -1, 1.41421356),
             (-1, 0, 1.0), (1, 0, 1.0),
             (-1, 1, 1.41421356), (0, 1, 1.0), (1, 1, 1.41421356)]
    target_idx = sb[1] * sw + sb[0]

    while pq:
        d, idx = heapq.heappop(pq)
        y, x = divmod(idx, sw)
        if visited[y, x]:
            continue
        visited[y, x] = True
        if idx == target_idx:
            break
        for dx, dy, step in neigh:
            nx, ny = x + dx, y + dy
            if 0 <= nx < sw and 0 <= ny < sh and not visited[ny, nx]:
                nd = d + step * sub[ny, nx]
                if nd < dist[ny, nx]:
                    dist[ny, nx] = nd
                    came[ny, nx] = idx
                    heapq.heappush(pq, (nd, ny * sw + nx))

    # backtrack
    path = []
    idx = target_idx
    guard = 0
    while idx != -1 and guard < sh * sw:
        y, x = divmod(int(idx), sw)
        path.append((x + x0, y + y0))
        if idx == sa[1] * sw + sa[0]:
            break
        idx = came[y, x]
        guard += 1
    path.reverse()
    if not path:
        path = [(ax, ay), (bx, by)]
    return path


def polyline_length(path):
    if len(path) < 2:
        return 0.0
    p = np.asarray(path, dtype=np.float64)
    return float(np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1)))


def fit_circle_ls(points):
    """Algebraic (Kasa) least-squares circle. Returns (cx, cy, r)."""
    p = np.asarray(points, dtype=np.float64)
    x, y = p[:, 0], p[:, 1]
    A = np.column_stack([x, y, np.ones(len(p))])
    b = x ** 2 + y ** 2
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    cx, cy = sol[0] / 2.0, sol[1] / 2.0
    r = float(np.sqrt(max(0.0, sol[2] + cx ** 2 + cy ** 2)))
    return float(cx), float(cy), r


def refine_circle(edge, cx, cy, r, band=6, thresh=0.3):
    """Refit the circle using edge pixels within +/-band of the initial radius."""
    ys, xs = np.nonzero(edge >= thresh)
    if len(xs) < 5:
        return cx, cy, r
    d = np.sqrt((xs - cx) ** 2 + (ys - cy) ** 2)
    keep = np.abs(d - r) <= band
    if keep.sum() < 5:
        return cx, cy, r
    return fit_circle_ls(np.column_stack([xs[keep], ys[keep]]))
