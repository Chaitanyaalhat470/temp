"""
DexiNed edge detector (optional backend).

The full architecture is embedded so no external repo is needed. Used only
when settings.EDGE_METHOD == "dexined" and torch + 10_model.pth are present.
Otherwise the Canny backend in edges.py is used and torch is never imported.
"""
import numpy as np
import cv2

DEXINED_MEAN = np.array([103.939, 116.779, 123.68], dtype=np.float32)

_MODEL = None
_DEVICE = None


def _build_model():
    import torch
    import torch.nn as nn
    import torch.nn.functional as F

    def weight_init(m):
        if isinstance(m, nn.Conv2d):
            torch.nn.init.xavier_normal_(m.weight, gain=1.0)
            if m.weight.data.shape[1] == torch.Size([1]):
                torch.nn.init.normal_(m.weight, mean=0.0)
            if m.bias is not None:
                torch.nn.init.zeros_(m.bias)
        if isinstance(m, nn.ConvTranspose2d):
            torch.nn.init.xavier_normal_(m.weight, gain=1.0)
            if m.weight.data.shape[1] == torch.Size([1]):
                torch.nn.init.normal_(m.weight, std=0.1)
            if m.bias is not None:
                torch.nn.init.zeros_(m.bias)

    class _DenseLayer(nn.Sequential):
        def __init__(self, in_f, out_f):
            super().__init__()
            self.add_module('conv1', nn.Conv2d(in_f, out_f, 3, 1, 2, bias=True))
            self.add_module('norm1', nn.BatchNorm2d(out_f))
            self.add_module('relu1', nn.ReLU(inplace=True))
            self.add_module('conv2', nn.Conv2d(out_f, out_f, 3, 1, bias=True))
            self.add_module('norm2', nn.BatchNorm2d(out_f))

        def forward(self, x):
            x1, x2 = x
            new = super().forward(F.relu(x1))
            return 0.5 * (new + x2), x2

    class _DenseBlock(nn.Sequential):
        def __init__(self, n, in_f, out_f):
            super().__init__()
            for i in range(n):
                self.add_module('denselayer%d' % (i + 1), _DenseLayer(in_f, out_f))
                in_f = out_f

    class UpConvBlock(nn.Module):
        def __init__(self, in_f, up_scale):
            super().__init__()
            self.constant_features = 16
            layers, all_pads = [], [0, 0, 1, 3, 7]
            for i in range(up_scale):
                ks = 2 ** up_scale
                pad = all_pads[up_scale]
                of = 1 if i == up_scale - 1 else self.constant_features
                layers.append(nn.Conv2d(in_f, of, 1))
                layers.append(nn.ReLU(inplace=True))
                layers.append(nn.ConvTranspose2d(of, of, ks, stride=2, padding=pad))
                in_f = of
            self.features = nn.Sequential(*layers)

        def forward(self, x):
            return self.features(x)

    class SingleConvBlock(nn.Module):
        def __init__(self, in_f, out_f, stride, use_bs=True):
            super().__init__()
            self.use_bn = use_bs
            self.conv = nn.Conv2d(in_f, out_f, 1, stride=stride, bias=True)
            self.bn = nn.BatchNorm2d(out_f)

        def forward(self, x):
            x = self.conv(x)
            return self.bn(x) if self.use_bn else x

    class DoubleConvBlock(nn.Module):
        def __init__(self, in_f, mid_f, out_f=None, stride=1, use_act=True):
            super().__init__()
            self.use_act = use_act
            out_f = out_f or mid_f
            self.conv1 = nn.Conv2d(in_f, mid_f, 3, padding=1, stride=stride)
            self.bn1 = nn.BatchNorm2d(mid_f)
            self.conv2 = nn.Conv2d(mid_f, out_f, 3, padding=1)
            self.bn2 = nn.BatchNorm2d(out_f)
            self.relu = nn.ReLU(inplace=True)

        def forward(self, x):
            x = self.relu(self.bn1(self.conv1(x)))
            x = self.bn2(self.conv2(x))
            return self.relu(x) if self.use_act else x

    class DexiNed(nn.Module):
        def __init__(self):
            super().__init__()
            self.block_1 = DoubleConvBlock(3, 32, 64, stride=2)
            self.block_2 = DoubleConvBlock(64, 128, use_act=False)
            self.dblock_3 = _DenseBlock(2, 128, 256)
            self.dblock_4 = _DenseBlock(3, 256, 512)
            self.dblock_5 = _DenseBlock(3, 512, 512)
            self.dblock_6 = _DenseBlock(3, 512, 256)
            self.maxpool = nn.MaxPool2d(3, stride=2, padding=1)
            self.side_1 = SingleConvBlock(64, 128, 2)
            self.side_2 = SingleConvBlock(128, 256, 2)
            self.side_3 = SingleConvBlock(256, 512, 2)
            self.side_4 = SingleConvBlock(512, 512, 1)
            self.side_5 = SingleConvBlock(512, 256, 1)
            self.pre_dense_2 = SingleConvBlock(128, 256, 2)
            self.pre_dense_3 = SingleConvBlock(128, 256, 1)
            self.pre_dense_4 = SingleConvBlock(256, 512, 1)
            self.pre_dense_5 = SingleConvBlock(512, 512, 1)
            self.pre_dense_6 = SingleConvBlock(512, 256, 1)
            self.up_block_1 = UpConvBlock(64, 1)
            self.up_block_2 = UpConvBlock(128, 1)
            self.up_block_3 = UpConvBlock(256, 2)
            self.up_block_4 = UpConvBlock(512, 3)
            self.up_block_5 = UpConvBlock(512, 4)
            self.up_block_6 = UpConvBlock(256, 4)
            self.block_cat = SingleConvBlock(6, 1, stride=1, use_bs=False)
            self.apply(weight_init)

        def forward(self, x):
            b1 = self.block_1(x)
            b1s = self.side_1(b1)
            b2 = self.block_2(b1)
            b2d = self.maxpool(b2)
            b2a = b2d + b1s
            b2s = self.side_2(b2a)
            b3pd = self.pre_dense_3(b2d)
            b3, _ = self.dblock_3([b2a, b3pd])
            b3d = self.maxpool(b3)
            b3a = b3d + b2s
            b3s = self.side_3(b3a)
            b4pd256 = self.pre_dense_2(b2d)
            b4pd = self.pre_dense_4(b4pd256 + b3d)
            b4, _ = self.dblock_4([b3a, b4pd])
            b4d = self.maxpool(b4)
            b4a = b4d + b3s
            b4s = self.side_4(b4a)
            b5pd = self.pre_dense_5(b4d)
            b5, _ = self.dblock_5([b4a, b5pd])
            b5a = b5 + b4s
            b6pd = self.pre_dense_6(b5)
            b6, _ = self.dblock_6([b5a, b6pd])
            out = [self.up_block_1(b1), self.up_block_2(b2), self.up_block_3(b3),
                   self.up_block_4(b4), self.up_block_5(b5), self.up_block_6(b6)]
            cat = self.block_cat(__import__("torch").cat(out, dim=1))
            out.append(cat)
            return out

    return DexiNed


def _round16(v):
    return int(np.ceil(v / 16) * 16)


def edge_map(bgr, weights_path, device=None):
    """Return DexiNed fused edge map in [0,1] at the original size."""
    global _MODEL, _DEVICE
    import torch

    if _MODEL is None:
        _DEVICE = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        model = _build_model()().to(_DEVICE)
        model.load_state_dict(torch.load(weights_path, map_location=_DEVICE))
        model.eval()
        _MODEL = model

    h, w = bgr.shape[:2]
    nh, nw = _round16(h), _round16(w)
    resized = cv2.resize(bgr, (nw, nh))
    img = resized.astype(np.float32) - DEXINED_MEAN
    tensor = torch.from_numpy(img.transpose(2, 0, 1)).unsqueeze(0).to(_DEVICE)
    with torch.no_grad():
        preds = _MODEL(tensor)
    edge = torch.sigmoid(preds[-1])[0, 0].cpu().numpy()
    edge = cv2.resize(edge, (w, h))
    return (edge - edge.min()) / (edge.max() - edge.min() + 1e-8)
