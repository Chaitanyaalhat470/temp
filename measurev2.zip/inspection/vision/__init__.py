"""Vision pipeline: edge detection, Livewire measurement, registration."""
