"""
Checkerboard calibration for the web app (scale only).

Reuses the corner-detection logic from the standalone calibrate.py: detect the
checkerboard, measure the mean pixel spacing between adjacent inner corners,
and derive mm-per-pixel from the known square size. On a fixed top-down rig
this single-image scale is all the measurement pipeline needs.
"""
import numpy as np
import cv2


def find_corners(gray, pattern):
    """Detect + sub-pixel-refine checkerboard inner corners. None if not found."""
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
    ok, corners = cv2.findChessboardCorners(gray, pattern, flags)
    if not ok:
        return None
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)
    return cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)


def mean_corner_spacing_px(corners, pattern):
    """Average pixel distance between adjacent inner corners (H and V)."""
    cols, rows = pattern
    pts = corners.reshape(rows, cols, 2)
    dx = np.linalg.norm(pts[:, 1:, :] - pts[:, :-1, :], axis=2)
    dy = np.linalg.norm(pts[1:, :, :] - pts[:-1, :, :], axis=2)
    return float(np.mean(np.concatenate([dx.ravel(), dy.ravel()])))


def mm_per_px_from_image(bgr, cols, rows, square_mm):
    """
    Return (mm_per_px, spacing_px). `cols`/`rows` are INNER corners
    (squares - 1). Raises ValueError if no board is detected.
    """
    pattern = (int(cols), int(rows))
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    corners = find_corners(gray, pattern)
    if corners is None:
        raise ValueError(
            f"No {cols}x{rows} checkerboard detected. Check the INNER-corner "
            "counts (squares minus 1) and that the whole board is visible.")
    spacing = mean_corner_spacing_px(corners, pattern)
    if spacing <= 0:
        raise ValueError("Degenerate corner spacing.")
    return square_mm / spacing, spacing
