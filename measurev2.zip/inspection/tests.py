from django.test import TestCase

# Vision unit tests can go here (e.g. circle fit accuracy on synthetic data).
