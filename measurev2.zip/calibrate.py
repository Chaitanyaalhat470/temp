"""
calibrate.py  --  Phase 2, Step 1: one-time camera calibration
================================================================

Your rig is a FIXED, TOP-DOWN camera with controlled lighting. Because the
camera never moves, we calibrate ONCE and reuse the result for every grating.

This script does two things from checkerboard images:

  1) Lens-distortion calibration  -> camera matrix + distortion coefficients
     (so straight bars in the world stay straight in the image).
  2) Scale calibration            -> mm-per-pixel, from the known square size
     of a checkerboard laid flat on the staging surface.

Output: calibration.npz  (loaded by the measurement script in the next step).

----------------------------------------------------------------------------
HOW TO CAPTURE (one time)
----------------------------------------------------------------------------
  * Print a checkerboard, mount it FLAT and RIGID (glue to a board).
  * Take ~10-15 photos with the board in different positions/tilts across the
    frame  -> used for distortion calibration.
  * Take at least one photo with the board lying FLAT on the staging surface,
    at the SAME height a grating will sit  -> used for the mm/px scale.
  * Put all photos in one folder.

----------------------------------------------------------------------------
USAGE
----------------------------------------------------------------------------
  pip install opencv-contrib-python numpy

  python calibrate.py --images "calib/*.jpg" --cols 9 --rows 6 --square-mm 25

  # --cols/--rows are INNER corners (squares - 1), NOT the number of squares.
  # --square-mm is the real edge length of one checkerboard square in mm.

The flat-on-surface scale image is auto-detected as the one whose board fills
the most area; override with --scale-image path/to/that.jpg if needed.
"""

import os
import glob
import argparse

import cv2
import numpy as np


def find_corners(gray, pattern):
    """Locate + sub-pixel-refine checkerboard inner corners. None if not found."""
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
    ok, corners = cv2.findChessboardCorners(gray, pattern, flags)
    if not ok:
        return None
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1e-3)
    return cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)


def mean_corner_spacing_px(corners, pattern):
    """Average pixel distance between horizontally adjacent inner corners."""
    cols, rows = pattern
    pts = corners.reshape(rows, cols, 2)
    # horizontal neighbours
    dx = np.linalg.norm(pts[:, 1:, :] - pts[:, :-1, :], axis=2)
    # vertical neighbours
    dy = np.linalg.norm(pts[1:, :, :] - pts[:-1, :, :], axis=2)
    return float(np.mean(np.concatenate([dx.ravel(), dy.ravel()])))


def main():
    ap = argparse.ArgumentParser(description="One-time top-down camera calibration.")
    ap.add_argument("--images", required=True,
                    help='glob for checkerboard photos, e.g. "calib/*.jpg"')
    ap.add_argument("--cols", type=int, required=True,
                    help="inner corners per row (squares_per_row - 1)")
    ap.add_argument("--rows", type=int, required=True,
                    help="inner corners per column (squares_per_col - 1)")
    ap.add_argument("--square-mm", type=float, required=True,
                    help="real edge length of one checkerboard square, in mm")
    ap.add_argument("--scale-image", default=None,
                    help="photo of board flat on the staging surface "
                         "(default: auto-pick the one filling the most area)")
    ap.add_argument("--output", default="calibration.npz")
    args = ap.parse_args()

    pattern = (args.cols, args.rows)        # OpenCV wants (cols, rows)
    paths = sorted(glob.glob(args.images))
    if not paths:
        raise FileNotFoundError(f"No images matched: {args.images}")

    # Object points: checkerboard corners in real mm coordinates (Z=0 plane).
    objp = np.zeros((args.rows * args.cols, 3), np.float32)
    objp[:, :2] = np.mgrid[0:args.cols, 0:args.rows].T.reshape(-1, 2)
    objp *= args.square_mm

    objpoints, imgpoints, used = [], [], []
    img_size = None
    detections = {}        # path -> corners (for scale step)

    for p in paths:
        img = cv2.imread(p, cv2.IMREAD_COLOR)
        if img is None:
            print(f"[skip] unreadable: {p}")
            continue
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        corners = find_corners(gray, pattern)
        if corners is None:
            print(f"[skip] no {args.cols}x{args.rows} board found: {p}")
            continue
        objpoints.append(objp)
        imgpoints.append(corners)
        used.append(p)
        detections[p] = corners
        img_size = gray.shape[::-1]         # (w, h)
        print(f"[ok]   detected board: {os.path.basename(p)}")

    if len(objpoints) < 3:
        raise RuntimeError(
            f"Only {len(objpoints)} usable board(s). Need >=3 (ideally 10-15) "
            "with varied positions/tilts for a reliable distortion estimate.")

    print(f"[i] calibrating from {len(objpoints)} views ...")
    rms, mtx, dist, _rvecs, _tvecs = cv2.calibrateCamera(
        objpoints, imgpoints, img_size, None, None)
    print(f"[i] RMS reprojection error: {rms:.3f} px  (lower is better; <0.5 is good)")

    # --- mm/px scale, measured on an UNDISTORTED flat-on-surface board ---
    if args.scale_image:
        scale_path = args.scale_image
        if scale_path not in detections:
            simg = cv2.imread(scale_path, cv2.IMREAD_COLOR)
            sgray = cv2.cvtColor(simg, cv2.COLOR_BGR2GRAY)
            sc = find_corners(sgray, pattern)
            if sc is None:
                raise RuntimeError(f"No board found in scale image: {scale_path}")
            detections[scale_path] = sc
    else:
        # auto-pick: board whose corners span the largest bounding area
        def span(c):
            x, y, w, h = cv2.boundingRect(c.astype(np.float32))
            return w * h
        scale_path = max(detections, key=lambda k: span(detections[k]))
        print(f"[i] auto-picked scale image: {os.path.basename(scale_path)}")

    # undistort just the corner points, then measure their spacing
    raw = detections[scale_path]
    undist = cv2.undistortPoints(raw, mtx, dist, P=mtx)
    spacing_px = mean_corner_spacing_px(undist, pattern)
    mm_per_px = args.square_mm / spacing_px
    print(f"[i] corner spacing: {spacing_px:.3f} px  ->  mm/px = {mm_per_px:.5f}")

    np.savez(args.output,
             camera_matrix=mtx,
             dist_coeffs=dist,
             mm_per_px=mm_per_px,
             image_size=np.array(img_size),
             rms=rms,
             square_mm=args.square_mm,
             pattern=np.array(pattern))
    print(f"[done] saved calibration -> {args.output}")
    print("       (camera_matrix, dist_coeffs, mm_per_px). "
          "The measurement script will load this.")


if __name__ == "__main__":
    main()
