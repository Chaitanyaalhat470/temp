"""
Django settings for the Grating Measurement (AOI) project.

Single-machine internal tool: DEBUG on, permissive hosts, SQLite. Tighten
before any real deployment.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Security (dev defaults -- change for production)
# ---------------------------------------------------------------------------
SECRET_KEY = os.environ.get(
    "DJANGO_SECRET_KEY", "dev-only-insecure-key-change-me-please")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = ["*"]

# ---------------------------------------------------------------------------
# Applications
# ---------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "inspection",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "measure_project.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "measure_project.wsgi.application"
ASGI_APPLICATION = "measure_project.asgi.application"

# ---------------------------------------------------------------------------
# Database -- SQLite
# ---------------------------------------------------------------------------
DATABASES = {
    "default": {
        "ENGINE": "django.db.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# ---------------------------------------------------------------------------
# Password validation
# ---------------------------------------------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation."
             "UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation."
             "CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation."
             "NumericPasswordValidator"},
]

# ---------------------------------------------------------------------------
# I18N
# ---------------------------------------------------------------------------
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# ---------------------------------------------------------------------------
# Static & media
# ---------------------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"] if (BASE_DIR / "static").exists() else []
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Allow large image uploads to be handled in memory comfortably.
DATA_UPLOAD_MAX_MEMORY_SIZE = 50 * 1024 * 1024     # 50 MB

# ---------------------------------------------------------------------------
# Vision pipeline configuration
# ---------------------------------------------------------------------------
# Edge detector: "canny" (no extra deps, great for clean rig images) or
# "dexined" (needs torch + 10_model.pth; more robust on messy images).
# Edge detector: "canny" (default, no extra deps) or "dexined" (needs torch +
# 10_model.pth). Change the fallback below to switch without an env var.
# .strip("'\"") tolerates `set EDGE_METHOD='dexined'` (cmd keeps the quotes).
EDGE_METHOD = os.environ.get("EDGE_METHOD", "dexined").strip().strip("'\"").lower()
DEXINED_WEIGHTS = os.environ.get(
    "DEXINED_WEIGHTS", str(BASE_DIR / "10_model.pth")).strip().strip("'\"")

# rembg background removal before edge detection (slower, usually unnecessary
# on a controlled rig with a plain background).
USE_REMBG = os.environ.get("USE_REMBG", "0") == "1"
REMBG_MODEL = os.environ.get("REMBG_MODEL", "u2net")
