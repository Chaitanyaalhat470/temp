/* Reusable image canvas: draws an image at native resolution, maps clicks to
   image pixels, and re-renders overlays (points / paths / circles / quad). */

class ImageCanvas {
  constructor(canvasEl) {
    this.canvas = canvasEl;
    this.ctx = canvasEl.getContext("2d");
    this.img = null;
    this.edgeImg = null;
    this.showEdges = false;
    this.overlays = [];          // array of (ctx) => void
  }

  load(url) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => {
        this.img = im;
        this.canvas.width = im.naturalWidth;
        this.canvas.height = im.naturalHeight;
        this.redraw();
        resolve(im);
      };
      im.src = url;
    });
  }

  loadEdgeOverlay(url) {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => { this.edgeImg = im; this.redraw(); resolve(im); };
      im.src = url;
    });
  }

  setShowEdges(v) { this.showEdges = v; this.redraw(); }

  toImageCoords(evt) {
    const r = this.canvas.getBoundingClientRect();
    const x = (evt.clientX - r.left) * (this.canvas.width / r.width);
    const y = (evt.clientY - r.top) * (this.canvas.height / r.height);
    return { x: Math.round(x), y: Math.round(y) };
  }

  clearOverlays() { this.overlays = []; this.redraw(); }
  addOverlay(fn) { this.overlays.push(fn); this.redraw(); }

  redraw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    if (this.img) ctx.drawImage(this.img, 0, 0);
    if (this.showEdges && this.edgeImg) {
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.drawImage(this.edgeImg, 0, 0);
      ctx.restore();
    }
    for (const fn of this.overlays) fn(ctx);
  }
}

/* ---- drawing helpers (operate in image-pixel coords) ---- */
function drawPoint(ctx, p, color = "#2b62ff", r = 5) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(p.x ?? p[0], p.y ?? p[1], r, 0, Math.PI * 2);
  ctx.fill();
}

function drawPath(ctx, pts, color = "#ff2d2d", w = 3) {
  if (!pts || pts.length < 2) return;
  ctx.strokeStyle = color; ctx.lineWidth = w; ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.stroke();
}

function drawCircle(ctx, cx, cy, r, color = "#ff2d2d", w = 3) {
  ctx.strokeStyle = color; ctx.lineWidth = w;
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
  drawPoint(ctx, { x: cx, y: cy }, color, 3);
}

function drawQuad(ctx, quad, color = "#00d28a", w = 2) {
  if (!quad) return;
  ctx.strokeStyle = color; ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(quad[0][0], quad[0][1]);
  for (let i = 1; i < quad.length; i++) ctx.lineTo(quad[i][0], quad[i][1]);
  ctx.closePath(); ctx.stroke();
}

function drawLabel(ctx, x, y, text, color = "#ffffff", bg = "#1c2230") {
  ctx.font = "600 18px sans-serif";
  const w = ctx.measureText(text).width + 12;
  ctx.fillStyle = bg; ctx.fillRect(x, y - 22, w, 24);
  ctx.fillStyle = color; ctx.fillText(text, x + 6, y - 4);
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
