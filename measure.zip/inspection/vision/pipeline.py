"""
High-level pipeline used by the Django views.

  prepare_image(path)         -> edge map (cached), outer outline, overlay PNG
  measure_length(path, a, b)  -> snapped path + pixel length
  measure_circle(path, pts)   -> fitted circle (cx, cy, r) in pixels
  auto_measure(gtype, path)   -> register subject to master (silhouette) and
                                 replay all features on the subject's own edges
"""
import os
import hashlib

import cv2
import numpy as np
from django.conf import settings

from . import edges as edges_mod
from . import measure as M
from . import registration as reg

# Cache (bgr, edge, cost) keyed by (abspath, mtime) so repeated clicks are fast.
_CACHE = {}


def _load_bgr(path):
    bgr = cv2.imread(path, cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(path)
    return bgr


def _edge_and_cost(path):
    key = (os.path.abspath(path), os.path.getmtime(path))
    if key in _CACHE:
        return _CACHE[key]
    bgr = _load_bgr(path)
    edge = edges_mod.compute_edge_map(bgr)
    cost = M.build_cost(edge)
    _CACHE[key] = (bgr, edge, cost)
    if len(_CACHE) > 16:
        _CACHE.pop(next(iter(_CACHE)))
    return _CACHE[key]


def _overlay_url(path, edge):
    bgr = _load_bgr(path)
    overlay = edges_mod.overlay_edges(bgr, edge, thresh=0.4)
    digest = hashlib.md5((os.path.abspath(path) +
                          str(os.path.getmtime(path))).encode()).hexdigest()[:12]
    out_dir = os.path.join(settings.MEDIA_ROOT, "edges")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{digest}.png")
    cv2.imwrite(out_path, overlay)
    return settings.MEDIA_URL + f"edges/{digest}.png"


def prepare_image(path):
    """Detect edges + outer outline; metadata for the canvas (any shape)."""
    bgr, edge, _cost = _edge_and_cost(path)
    h, w = bgr.shape[:2]
    outline = reg.outline_polygon(bgr)
    return {
        "width": int(w),
        "height": int(h),
        "outline": outline,
        "edge_overlay_url": _overlay_url(path, edge),
    }


def measure_length(path, a, b):
    _bgr, edge, cost = _edge_and_cost(path)
    sa = M.snap_to_edge(edge, a)
    sb = M.snap_to_edge(edge, b)
    path_pts = M.livewire_path(cost, sa, sb)
    return {
        "path": [[int(x), int(y)] for x, y in path_pts],
        "length_px": M.polyline_length(path_pts),
        "a": list(sa), "b": list(sb),
    }


def _local_edge(edge, cx, cy, r, pad=1.5):
    """Zero out edge pixels far from the circle so refine can't grab a far arc."""
    h, w = edge.shape
    rad = max(8.0, r * pad)
    x0, x1 = int(max(0, cx - rad)), int(min(w, cx + rad))
    y0, y1 = int(max(0, cy - rad)), int(min(h, cy + rad))
    local = np.zeros_like(edge)
    local[y0:y1, x0:x1] = edge[y0:y1, x0:x1]
    return local


def measure_circle(path, points):
    _bgr, edge, _cost = _edge_and_cost(path)
    snapped = [M.snap_to_edge(edge, p) for p in points]
    cx, cy, r = M.fit_circle_ls(snapped)
    cx, cy, r = M.refine_circle(_local_edge(edge, cx, cy, r), cx, cy, r)
    return {"cx": cx, "cy": cy, "r": r, "points": [list(p) for p in snapped]}


def auto_measure(grating_type, subject_path):
    """
    Register the subject to the master by silhouette (any shape), then replay
    every feature, re-measuring the subject's OWN edges.

    Returns (subject_outline, registered_bool, [result dicts]).
    """
    master_path = grating_type.master_image.path
    m_bgr, _m_edge, _m_cost = _edge_and_cost(master_path)
    master_mask, _ = reg.get_mask(m_bgr)

    s_bgr, s_edge, s_cost = _edge_and_cost(subject_path)
    subject_mask, subject_contour = reg.get_mask(s_bgr)
    subject_outline = reg.outline_polygon(s_bgr)

    T = reg.estimate_transform(master_mask, subject_mask)
    mm = grating_type.mm_per_px
    results = []

    if T is None:
        return subject_outline, False, results

    for feat in grating_type.features.all():
        try:
            if feat.kind == "length":
                a = feat.anchors_img["a"]
                b = feat.anchors_img["b"]
                a_img, b_img = reg.warp_points([a, b], T)
                sa = M.snap_to_edge(s_edge, a_img)
                sb = M.snap_to_edge(s_edge, b_img)
                path_pts = M.livewire_path(s_cost, sa, sb)
                px = M.polyline_length(path_pts)
                results.append({
                    "feature_id": feat.id, "name": feat.name, "kind": feat.kind,
                    "value_px": px,
                    "value_mm": (px * mm) if mm else None,
                    "geometry": {"path": [[int(x), int(y)] for x, y in path_pts]},
                    "ok": True,
                })
            elif feat.kind == "radius":
                pts = feat.anchors_img["points"]
                pts_img = reg.warp_points(pts, T)
                snapped = [M.snap_to_edge(s_edge, p) for p in pts_img]
                cx, cy, r = M.fit_circle_ls(snapped)
                cx, cy, r = M.refine_circle(_local_edge(s_edge, cx, cy, r), cx, cy, r)
                results.append({
                    "feature_id": feat.id, "name": feat.name, "kind": feat.kind,
                    "value_px": r,
                    "value_mm": (r * mm) if mm else None,
                    "geometry": {"cx": cx, "cy": cy, "r": r},
                    "ok": True,
                })
        except Exception as exc:                       # noqa: BLE001
            results.append({
                "feature_id": feat.id, "name": feat.name, "kind": feat.kind,
                "value_px": 0.0, "value_mm": None, "geometry": None,
                "ok": False, "note": str(exc),
            })
    return subject_outline, True, results
