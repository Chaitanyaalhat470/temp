"""
Views: HTML pages (index / calibration / teach / inspect) + JSON API endpoints
that the canvas frontend calls.

API endpoints are CSRF-exempt for simplicity (internal single-machine tool).
Add CSRF/auth before any networked deployment.
"""
import json

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from .models import (GratingType, Feature, InspectionRun, Measurement,
                     RigCalibration)
from .vision import pipeline


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------
def index(request):
    types = GratingType.objects.all()
    return render(request, "inspection/index.html",
                  {"types": types, "calib": RigCalibration.current()})


def calibration(request):
    """Set the single global mm/px for the fixed-FOV rig."""
    calib = RigCalibration.current()
    if request.method == "POST":
        mm_per_px = _float_or_none(request.POST.get("mm_per_px"))
        if not mm_per_px or mm_per_px <= 0:
            return render(request, "inspection/calibration.html",
                          {"calib": calib, "error": "Enter a positive mm/px value."})
        RigCalibration.objects.create(
            mm_per_px=mm_per_px, source=request.POST.get("source", ""))
        return redirect("index")
    return render(request, "inspection/calibration.html", {"calib": calib})


def create_type(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        if not name or "master_image" not in request.FILES:
            return render(request, "inspection/create_type.html",
                          {"error": "Name and master image are required.",
                           "calib": RigCalibration.current()})

        calib = RigCalibration.current()
        gtype = GratingType.objects.create(
            name=name,
            description=request.POST.get("description", ""),
            master_image=request.FILES["master_image"],
            mm_per_px=(calib.mm_per_px if calib else None),
        )
        return redirect("teach", type_id=gtype.id)

    return render(request, "inspection/create_type.html",
                  {"calib": RigCalibration.current()})


def teach(request, type_id):
    gtype = get_object_or_404(GratingType, pk=type_id)
    meta = pipeline.prepare_image(gtype.master_image.path)
    ctx = {
        "gtype": gtype,
        "meta_json": json.dumps(meta),
        "image_url": gtype.master_image.url,
    }
    return render(request, "inspection/teach.html", ctx)


def inspect(request, type_id):
    gtype = get_object_or_404(GratingType, pk=type_id)
    runs = gtype.runs.all()[:25]
    return render(request, "inspection/inspect.html",
                  {"gtype": gtype, "runs": runs})


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
def _float_or_none(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _resolve_image_path(payload):
    if payload.get("run_id"):
        run = get_object_or_404(InspectionRun, pk=payload["run_id"])
        return run.subject_image.path
    gtype = get_object_or_404(GratingType, pk=payload["type_id"])
    return gtype.master_image.path


@csrf_exempt
@require_POST
def api_prepare(request):
    payload = json.loads(request.body or "{}")
    return JsonResponse(pipeline.prepare_image(_resolve_image_path(payload)))


@csrf_exempt
@require_POST
def api_measure_length(request):
    payload = json.loads(request.body or "{}")
    path = _resolve_image_path(payload)
    return JsonResponse(pipeline.measure_length(path, payload["a"], payload["b"]))


@csrf_exempt
@require_POST
def api_measure_circle(request):
    payload = json.loads(request.body or "{}")
    path = _resolve_image_path(payload)
    return JsonResponse(pipeline.measure_circle(path, payload["points"]))


@csrf_exempt
@require_POST
def api_save_features(request, type_id):
    """
    Persist taught features. Anchors arrive in MASTER-IMAGE pixels and are
    stored as-is (registration handles the transfer to subjects). Replaces the
    type's existing features.
    """
    gtype = get_object_or_404(GratingType, pk=type_id)
    payload = json.loads(request.body or "{}")

    gtype.features.all().delete()
    created = []
    for f in payload.get("features", []):
        kind = f["kind"]
        if kind == "length":
            anchors = {"a": f["a"], "b": f["b"]}
        elif kind == "radius":
            anchors = {"points": f["points"]}
        else:
            continue
        feat = Feature.objects.create(
            grating_type=gtype, name=f["name"], kind=kind, anchors_img=anchors)
        created.append(feat.id)

    return JsonResponse({"saved": created})


@csrf_exempt
@require_POST
def api_inspect(request, type_id):
    """Run auto-measurement on an uploaded subject image (any shape)."""
    gtype = get_object_or_404(GratingType, pk=type_id)
    if not gtype.is_taught:
        return HttpResponseBadRequest("This grating type has no taught features yet.")
    if "subject_image" not in request.FILES:
        return HttpResponseBadRequest("subject_image file is required.")

    run = InspectionRun.objects.create(
        grating_type=gtype, subject_image=request.FILES["subject_image"])

    outline, registered, results = pipeline.auto_measure(
        gtype, run.subject_image.path)
    run.subject_outline = outline
    run.save()

    for r in results:
        Measurement.objects.create(
            run=run, feature_id=r["feature_id"],
            value_px=r["value_px"], value_mm=r["value_mm"],
            unit="mm" if r["value_mm"] is not None else "px",
            geometry=r["geometry"], ok=r["ok"], note=r.get("note", ""))

    return JsonResponse({
        "run_id": run.id,
        "image_url": run.subject_image.url,
        "outline": outline,
        "registered": registered,
        "results": results,
    })
